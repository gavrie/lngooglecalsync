#!/bin/sh

# This script runs LNConnectivityTest on Linux and OS X.

# NOTE: When the Java application prompts for input, you may have to
# type the input, press Enter, then press Ctrl+M. 

OS_TYPE=`uname`
if [ $OS_TYPE == "Linux" ]; then
  NOTES_PATH=/opt/ibm/lotus/notes
  export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$NOTES_PATH
fi
if [ $OS_TYPE == "Darwin" ]; then
  export NOTES_PATH=/Applications/Notes.app/Contents/MacOS
  export PATH=$PATH:$NOTES_PATH
  export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$NOTES_PATH
  export CLASSPATH=$CLASSPATH:$NOTES_PATH:$NOTES_PATH/jvm/lib/ext/Notes.jar
  export DYLD_LIBRARY_PATH=$DYLD_LIBRARY_PATH:$NOTES_PATH
fi

export PATH=$PATH:$NOTES_PATH
export MY_CLASSPATH=$NOTES_PATH/jvm/lib/ext/Notes.jar:./LNConnectivityTest.jar

echo Classpath $MY_CLASSPATH
java -cp "$MY_CLASSPATH" lnconnectivitytest.Main

