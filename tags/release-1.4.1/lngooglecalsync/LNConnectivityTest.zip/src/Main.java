package lnconnectivitytest;

import java.io.*;
import java.util.*;
import lotus.domino.*;

public class Main {

    public static void main(String[] args) throws IOException {
        boolean wasNotesThreadInitialized = false;

        System.out.println("Starting Lotus Notes connectivity test.");

        System.out.println("");
        System.out.println("OS: " + System.getProperty("os.name") + " " + System.getProperty("os.version"));
        System.out.println("Java: " + System.getProperty("java.version") + " " + System.getProperty("java.vendor"));
        System.out.println("Java Classpath: " + System.getProperty("java.class.path"));
        System.out.println("Java Library Path: " + System.getProperty("java.library.path"));
        System.out.println("");

        try {
            // Some users, especially on OS X, have trouble locating Notes.jar (which
            // needs to be in the classpath) and the supporting dll/so/dylib files (which
            // need to be in the path/ld_library_path).  Try to load one of the Lotus
            // classes to make sure we can find Notes.jar.
            // The next try/catch block (with the sinitThread() call) will check if
            // the supporing dlls can be found.
            ClassLoader.getSystemClassLoader().loadClass("lotus.domino.NotesThread");
        } catch (Exception ex) {
            System.out.println("The Lotus Notes Java interface file (Notes.jar) could not be found.\nMake sure Notes.jar is in your classpath.");
            ex.printStackTrace();
            System.exit(1);
        }

        // I don't know why, but if you call NotesThread.sinitThread() in a
        // try/catch block with other statements, then sinitThread() won't
        // throw an exception on error. So, use a separate try/catch block.
        try {
            // Make sure your Windows PATH statement includes the location
            // for the Lotus main directory, e.g. "c:\Program Files\Lotus\Notes".
            // This is necessary because the Java classes call native/C dlls in
            // this directory.
            // If the dlls can't be found, then we will drop directly into
            // the finally section (no exception is thrown).  That's strange.
            // So, we set a flag to indicate whether things succeeded or not.
            // Produces deprecation message:
            NotesThread.sinitThread();
            wasNotesThreadInitialized = true;
        } catch (Exception ex) {
            System.out.println("There was a problem initializing the Lotus Notes thread.\nMake sure the Lotus dll/so/dylib directory is in your path.");
            ex.printStackTrace();
            System.exit(1);
        } finally {
            if (!wasNotesThreadInitialized)
                System.out.println("Connectivity test FAILED!");
        }
        
        try {
            System.out.println("Connecting to local sever.");

            String password = "test";
            // Note: We cast null to a String to avoid overload conflicts
            Session session = NotesFactory.createSession((String)null, (String)null, password);

            String mailfile = "test2";
            Database db = session.getDatabase(null, mailfile, false);
            if (db == null)
                throw new Exception("Couldn't create Lotus Notes Database object.");

            System.out.println("Lotus Notes version: " + session.getNotesVersion());
        } catch (Exception ex) {
            System.out.println("There was a problem connecting to the local mail file.");
            ex.printStackTrace();
            System.exit(1);
        } finally {
            NotesThread.stermThread();
        }

        System.out.println("Connectivity test was successful.");
        System.exit(0);
    }

}
