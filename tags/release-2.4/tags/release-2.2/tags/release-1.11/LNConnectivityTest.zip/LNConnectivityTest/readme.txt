LN Connectivity Test verifies that a Java application can successfully
connect to Lotus Notes.

To run the app under Windows, use lnconntest.vbs.
To run the app under Linux or OS X, use lnconntest.vsh.
