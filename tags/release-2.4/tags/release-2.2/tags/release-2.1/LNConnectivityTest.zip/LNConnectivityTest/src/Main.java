package lnconnectivitytest;

import java.io.*;
import java.util.*;
import lotus.domino.*;


public class Main {
    public static void main(String[] args) throws IOException {
        System.out.println("Starting Lotus Notes connectivity test.");

        String javaClassPath = System.getProperty("java.class.path");
        String javaLibPath = System.getProperty("java.library.path");
        String fileSeparator = System.getProperty("file.separator");
        String pathSeparator = System.getProperty("path.separator");

        System.out.println("");
        System.out.println("Application Version: " + appVersion);
        System.out.println("OS: " + System.getProperty("os.name") + " " + System.getProperty("os.version") + " " + System.getProperty("os.arch"));
        // Display all args that were passed in. They are data values we want to show the user.
        for (String arg : args) {
            System.out.println(arg.replace(":", ": "));
        }
        System.out.println("Java: " + System.getProperty("java.version") + " " + System.getProperty("java.vendor"));
        System.out.println("Java Home: " + System.getProperty("java.home"));
        System.out.println("\nJava Classpath: " + javaClassPath);
        System.out.println("\nJava Library Path: " + javaLibPath);

        System.out.println("");

        rc = FindNotesIni(javaLibPath, pathSeparator, fileSeparator);
        if (rc == 0)
            rc = LoadNotesThreadClass();
        if (rc == 0)
            rc = InitNotesThread();
        
        Scanner consoleInput = null;

        try {
            System.out.println("\n=== Connecting to local sever without specifying a password.");
            Session session = NotesFactory.createSession();
            System.out.println("Notes version: " + session.getNotesVersion());
            System.out.println("Platform: " + session.getPlatform());
            System.out.println("Is on server: " + session.isOnServer());
            System.out.println("Success");

            System.out.println("\n=== Connecting to sever with a password.");
            String lnServer;
            System.out.print("Enter your Lotus Notes server (type \"local\" to use local server)> ");
            Console console = System.console();
            lnServer = console.readLine();

            // Read the password, without echoing the output
            char[] lnPasswordBuffer = console.readPassword("Enter your Lotus Notes password> ");
            String lnPassword = new String(lnPasswordBuffer);

            // Note: We cast null to a String to avoid overload conflicts
            session = NotesFactory.createSession((String)null, (String)null, lnPassword);

            String mailfile = session.getEnvironmentString("MailFile", true);
            if (mailfile == null || mailfile.isEmpty())
                throw new Exception("Couldn't get the mailfile name from notes.ini.");
            System.out.println("Common user name: " + session.getCommonUserName());
            System.out.println("KeyFilename: " + session.getEnvironmentString("KeyFilename", true));
            System.out.println("MailFile: " + mailfile);
            System.out.println("MailServer: " + session.getEnvironmentString("MailServer", true));
            System.out.println("Directory: " + session.getEnvironmentString("Directory", true));
            System.out.println("Success");

            System.out.println("\n=== Connecting to the Lotus Notes database.");
            String dominoServerTemp = lnServer;
            if (lnServer.equals("local"))
                dominoServerTemp = null;

            Database db = session.getDatabase(dominoServerTemp, mailfile, false);
            if (db == null)
                throw new Exception("Couldn't create Lotus Notes Database object.\nMake sure the server and mailfile names are correct.\nMake sure you have permissions to the .nsf file and that your notes.ini file isn't corrupt.");
            System.out.println("Success");
        } catch (Exception ex) {
            System.out.println("There was a problem connecting to the local mail file.");
            ex.printStackTrace();
            rc = 1;
        } finally {
            if (consoleInput != null)
                consoleInput.close();

            NotesThread.stermThread();
        }

        if (rc == 0)
            System.out.println("\n=== Connectivity test was successful.");
        else {
            System.out.println("\n=== Connectivity test FAILED!");
            System.out.println("Try reading the Troubleshooting section of HelpFile.html.");
            System.out.println("This help file is included with the main LNGS application.");
            System.out.println("If you need additional help, post to the Open Discussion forum:");
            System.out.println("https://sourceforge.net/projects/lngooglecalsync/forums");
        }

        System.exit(rc);
    }


    public static int InitNotesThread() {
        boolean wasNotesThreadInitialized = false;

        // I don't know why, but if you call NotesThread.sinitThread() in a
        // try/catch block with other statements, then sinitThread() won't
        // throw an exception on error. So, use a separate try/catch block.
        try {
            System.out.println("\n=== Initializing NotesThread.");
            // Make sure your Windows PATH statement includes the location
            // for the Lotus main directory, e.g. "c:\Program Files\Lotus\Notes".
            // This is necessary because the Java classes call native/C dlls in
            // this directory.
            // If the dlls can't be found, then we will drop directly into
            // the finally section (no exception is thrown).  That's strange.
            // So, we set a flag to indicate whether things succeeded or not.
            // Produces deprecation message:
            NotesThread.sinitThread();
            wasNotesThreadInitialized = true;
            System.out.println("Success");
        } catch (Exception ex) {
            System.out.println("There was a problem initializing the Lotus Notes thread.\nMake sure the Lotus dll/so/dylib directory is in your path.");
            ex.printStackTrace();
            return 1;
        } finally {
            if (!wasNotesThreadInitialized) {
                return 1;
            }
        }

        return 0;
    }


    public static int LoadNotesThreadClass() {
        try {
            System.out.println("\n=== Trying to manually load NotesThread class.");
            // Some users, especially on OS X, have trouble locating Notes.jar (which
            // needs to be in the classpath) and the supporting dll/so/dylib files (which
            // need to be in the path/ld_library_path).  Try to load one of the Lotus
            // classes to make sure we can find Notes.jar.
            // The next try/catch block (with the sinitThread() call) will check if
            // the supporing dlls can be found.
            ClassLoader.getSystemClassLoader().loadClass("lotus.domino.NotesThread");
            System.out.println("Success");
        } catch (Exception ex) {
            System.out.println("The Lotus Notes Java interface file (Notes.jar) could not be found.\nMake sure Notes.jar is in your classpath.");
            ex.printStackTrace();
            return 1;
        }

        return 0;
    }


    public static int FindNotesIni(String javaLibPath, String pathSeparator, String fileSeparator) {
        try {
            System.out.println("\n=== Checking location of notes.ini.");
            // Create a list of File objects. Comparing File objects compares the paths
            // and takes into account case sensitivity of the underlying OS.  Comparing
            // paths as strings is error prone.
            List<File> iniList = new ArrayList<File>();
            String[] libPaths = javaLibPath.split(pathSeparator);
            // Loop through all the library paths looking for notes.ini files
            for (String path : libPaths) {
                if (path.endsWith(fileSeparator)) {
                    // Remove trailing file separator
                    path = path.substring(0, path.length() - 1);
                }
                File f = new File(path + fileSeparator + "notes.ini");
                if (f.exists()) {
                    if (!iniList.contains(f)) {
                        iniList.add(f);
                    }
                }
            }
            for (File iniFile : iniList) {
                System.out.println("notes.ini file found here: " + iniFile.getAbsolutePath());
            }
            if (iniList.size() < 1) {
                System.out.println("WARNING: A notes.ini file was not found in the Java Library Path.");
            }
            if (iniList.size() > 1) {
                System.out.println("WARNING: More than one notes.ini files were found in the Java Library Path.");
            }
        } catch (Exception ex) {
            System.out.println("There was an error checking the Java Library Path.");
            ex.printStackTrace();
            return 1;
        }

        return 0;
    }

    final static String appVersion = "1.8";

    protected static int rc = 0;     // Return code
}
